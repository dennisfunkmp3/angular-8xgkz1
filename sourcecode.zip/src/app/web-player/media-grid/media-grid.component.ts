import {Component, ViewEncapsulation} from '@angular/core';

@Component({
    selector: 'media-grid',
    templateUrl: './media-grid.component.html',
    styleUrls: ['./media-grid.component.scss', './media-grid-item.component.scss'],
    encapsulation: ViewEncapsulation.None
})
export class MediaGridComponent {

}
