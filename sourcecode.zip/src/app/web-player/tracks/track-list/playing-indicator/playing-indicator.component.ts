import { Component, ViewEncapsulation } from '@angular/core';

@Component({
  selector: 'playing-indicator',
  templateUrl: './playing-indicator.component.html',
  styleUrls: ['./playing-indicator.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class PlayingIndicatorComponent {
}
